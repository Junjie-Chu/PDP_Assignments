
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdarg.h>
#include <math.h>

#include <mpi.h>

#include "utils.h"


void exitError( const char* msg, ... )
{
    int rank;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );

    char buf[255] = "";
    sprintf( buf, "[%d] ERROR: %s", rank, msg );

    va_list args;
    va_start( args, msg );
        printf("\n");
        vprintf( buf, args ); 
        printf("\n\n");
    va_end( args );

    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE );
} // exitError


#ifdef DEBUG
void trace( const char* msg, ... )
{
    int rank;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );

    char buf[255] = "";
    sprintf( buf, "[%d] %s", rank, msg );

    va_list args;
    va_start( args, msg );
        vprintf( buf, args ); 
    va_end( args );
} // trace

void traceVector( int* numbers, int backetSize )
{
    for( int i = 0; i < backetSize; ++i )
        trace( "numbers[%d] = %d\n", i, numbers[i] );
} // traceVector
#endif


void* g_malloc(size_t size)
{
    void* p = malloc( size );
    if( p == NULL )
        exitError( "(malloc:%d): Now you've done it. Out of memory!", size );

    return( p );
} // g_malloc

void* g_calloc( size_t num, size_t size)
{
    void* p = calloc( num, size );
    if( p == NULL )
        exitError( "(calloc:%d): Now you've done it. Out of memory!", size );

    return( p );
} // g_calloc


void* g_realloc( void *ptr, size_t size)
{
    // Avoid realloc per implementation defined behavior when size is zero.
    if( size == 0 )
        return( ptr );

    void* p = realloc( ptr, size );
    if( p == NULL )
        exitError( "(realloc:%d): Now you've done it. Out of memory!", size );

    return( p );
} // g_realloc


double get_wall_seconds() 
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
    return seconds;
} // get_wall_seconds


const char* formatStr(const char* fmt, ... )
{
    static char s[255] = "";
    va_list vl;
    va_start( vl, fmt );

    vsnprintf( s, sizeof(s), fmt, vl);

    va_end( vl );

    return( s );
} // formatStr


int intcompare( const void * a, const void * b ) 
{
   return ( *(int*)a - *(int*)b );
} // intcompare


// Vector must be sorted for this to work.
int getVectorMedian( int* numbers, int size )
{
    if( size == 0 )
        return( 0 );

    double median = 0;
    if( size % 2 != 0 )
        median = numbers[size / 2];
    else
        median = ((double)numbers[(size / 2) -1] + (double)numbers[(size / 2)]) / 2.0;

    return( lrint(median) );
    //return( (size % 2 != 0) ? numbers[size / 2] : (numbers[(size / 2) -1] + numbers[(size / 2)]) / 2 );
} // getVectorMedian


int getVectorMax( int* numbers, int backetSize )
{
    int max = numbers[0];
    for( int i = 0; i < backetSize; ++i )
        if( numbers[i] > max )
            max = numbers[i];

    return( max );
} // getVectorMax


int getVectorMean( int* numbers, int backetSize )
{
    double sum = 0; 
    for( int i = 0; i < backetSize; ++i )
        sum += numbers[i];

    sum = sum / (double)backetSize;
    return( lrint(sum) );
} // getVectorMean


int binarySearch(int* numbers, int l, int r, int pivot) 
{ 
    if( r >= l ) 
    { 
        const int mid = l + (r - l) / 2; 
        const int minusOne = mid -1 >= 0 ? mid -1 : 0;
        const int plusOne  = mid +1 <= r ? mid +1 : r;
  
        // Did we hit the spot? Return a good value. 
        // Values higher than pivot should start from spot up.
        if( numbers[mid] == pivot )
            return( mid );
        else
            if( numbers[mid] < pivot && numbers[plusOne] > pivot ) 
                return( plusOne );
            else
                if( numbers[minusOne] < pivot && numbers[mid] > pivot )
                    return( mid );

        // If element is smaller than mid, then it can only be present in left subarray.
        if( numbers[mid] > pivot ) 
            return( binarySearch( numbers, l, mid - 1, pivot ) ); 
  
        // Else the element can only be present in right subarray.
        return( binarySearch( numbers, mid + 1, r, pivot ) ); 
    } 
  
    // We reach here when all elements are either bigger or smaller than the pivot.
    return( -1 );
} // binarySearch


void splitLowHigh( int* numbers, int backetSize, int pivot, int** low, int* lowSize, int** high, int* highSize )
{
    // Find the pivot in the array.
    const int spot = binarySearch( numbers, 0, backetSize -1, pivot );

    if( spot == -1 )
    {
        // All elements are either smaller or bigger than the pivot.
        if( numbers[0] >= pivot )
        {
            *high = numbers;
            *highSize = backetSize; 
            *low = NULL; 
            *lowSize = 0;
        }
        else
        {
            *low = numbers;
            *lowSize = backetSize; 
            *high = NULL; 
            *highSize = 0;
        }
    }
    else
    {
        // Low is everything below the spot: [0, spot)
        *low = g_calloc( spot, sizeof(int) );
        memcpy( *low, numbers, spot * sizeof(int) );
        *lowSize = spot;

        // High is everything above the spot: [spot, end]
        *highSize = backetSize - spot;
        *high = g_calloc( *highSize , sizeof(int) );
        memcpy( *high, numbers + spot, *highSize * sizeof(int) );
    }
} // splitLowHigh


int* merge( int* low, int lowSize, int* high, int highSize )
{
    low = low != NULL ? g_realloc( low, (lowSize + highSize) * sizeof(int) ) : g_calloc( (lowSize + highSize), sizeof(int) );
    if( highSize != 0 )
    {
        memcpy( low + lowSize, high, highSize * sizeof(int) );
        free( high );
    }

    return( low );
} // merge


void sendBuffer( MPI_Comm comm, int sourceRank, int targetRank, int* buffer, int bufferSize )
{
    // Send size of buffer first. 
    MPI_Send( &bufferSize, 1, MPI_INT, targetRank, sourceRank, comm );

    // Then send the buffer itself. Buffer size can be zero.
    if( bufferSize != 0 )
        MPI_Send( buffer, bufferSize, MPI_INT, targetRank, sourceRank, comm );
} // sendBuffer


int* receiveBuffer( MPI_Comm comm, int sourceRank, int* bufferSize )
{
    // Get buffer size first. 
    MPI_Recv( bufferSize, 1, MPI_INT, sourceRank, sourceRank, comm, NULL );

    // Then get the buffer itself. Buffer size can be zero.
    if( *bufferSize != 0 )
    {
        int* buffer = g_calloc( *bufferSize, sizeof(int) );
        MPI_Recv( buffer, *bufferSize, MPI_INT, sourceRank, sourceRank, comm, NULL );

        return( buffer );
    }

    return( NULL );
} // receiveBuffer


int* readFile( const char* fileName, int rank, int nump, int* size )
{
    FILE* fp = fopen( fileName, "r" ); 
    if( fp == NULL ) 
        return( NULL );

    char buf[100] = "";
    int* numbers = NULL;
    int  cc = 0;

    // Read number of integers.
    if( fscanf( fp, "%s ", buf ) == 1 )
    {
        cc = atoi( buf );

        // Calculate this chunk.
        int chunk = cc / nump;
        int first = rank * chunk; 
        int last  = first + chunk -1;

        if( rank == nump -1 )
            last += cc % nump;
        *size = last - first +1;

        trace( "Reading from %d to % d\n", first, last );

        numbers = (int* )g_calloc( *size, sizeof(int) );

        // Start reading this process part.
        cc = 0;
        int cnum = 0;
        while( fscanf( fp, "%s ", buf ) == 1 ) 
        {
            if( cnum >= first && cnum <= last )   
                numbers[cc++] = atoi( buf );
            cnum++;
        }

    }

    fclose( fp );
    return( numbers );
} // readFile


void writeFile( const char* fileName, int* numbers, int backetSize )
{
    FILE* fp = fopen( fileName, "w" ); 
    if( fp == NULL ) 
        return;

    for( int i = 0; i < backetSize; ++i )
        fprintf( fp, "%d ", numbers[i] );

    fclose( fp );
} // writeFile 
