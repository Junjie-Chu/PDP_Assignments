#ifndef __UTILS_H__
#define __UTILS_H__

#include "mpi.h"

double get_wall_seconds();

const char* formatStr(const char* fmt, ... );

void* g_malloc(size_t size);

void* g_calloc( size_t num, size_t size);

void* g_realloc( void *ptr, size_t size);

int* readFile( const char* fileName, int rank, int nump, int* size );

void writeFile( const char* fileName, int* numbers, int backetSize );

void sendBuffer( MPI_Comm comm, int sourceRank, int targetRank, int* buffer, int bufferSize );

int* receiveBuffer( MPI_Comm comm, int sourceRank, int* bufferSize );

int intcompare( const void * a, const void * b );

// Vector must be sorted for this to work.
int getVectorMedian( int* numbers, int size );

int getVectorMax( int* numbers, int backetSize );

int getVectorMean( int* numbers, int backetSize );

int binarySearch(int* numbers, int l, int r, int pivot);

void splitLowHigh( int* numbers, int backetSize, int pivot, int** low, int* lowSize, int** high, int* highSize );

int* merge( int* low, int lowSize, int* high, int highSize );

void exitError( const char* msg, ... );

#ifdef DEBUG
    void trace( const char* msg, ... );
    void traceVector( int* numbers, int backetSize );
#else
    #define trace(expr, ...)                ((void)0)
    #define traceVector( expr1, expr2 )     ((void)0)
#endif

#endif
