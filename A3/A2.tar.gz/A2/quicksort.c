
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <mpi.h>

#include "utils.h"

// File parameters.
char* inputFile   = NULL;
char* outputFile  = NULL;

// Pivot strategy.
#define PIVOT_LOCAL_MEDIAN          ((int)1)
#define PIVOT_GROUP_MEDIAN          ((int)2)
#define PIVOT_GROUP_MEAN_MEDIAN     ((int)3)
#define PIVOT_VALUE_FIRST           PIVOT_LOCAL_MEDIAN
#define PIVOT_VALUE_LAST            PIVOT_GROUP_MEAN_MEDIAN

int pivotStrategy = PIVOT_GROUP_MEDIAN;

int globalRank = 0;
int globalNump = 0;

double executionTime = 0.0;


void startUp( int argc, char *argv[] )
{
    // Initializing MPI.
    MPI_Init( &argc, &argv );
    MPI_Comm_size( MPI_COMM_WORLD, &globalNump );
    MPI_Comm_rank( MPI_COMM_WORLD, &globalRank );

    if( (globalNump & (globalNump - 1)) != 0 )
        exitError("Number of processes must be power of 2");

    if( argc != 4 )
        exitError("Usage: quicksort inputFile outputFile pivotStrategy(%d-%d)", PIVOT_VALUE_FIRST, PIVOT_VALUE_LAST );

    inputFile     = strdup( argv[1] );
    outputFile    = strdup( argv[2] );
    pivotStrategy = atoi  ( argv[3] );

    if( pivotStrategy < PIVOT_VALUE_FIRST || pivotStrategy > PIVOT_VALUE_LAST )
        exitError("Invalid pivot option. (%d-%d)", PIVOT_VALUE_FIRST, PIVOT_VALUE_LAST );
} // startUp


void done()
{
    // Print out time for each process.
    trace("[%d] Elapsed time: %0.6f ws\n", globalRank, executionTime);

    // Wait for all to get here and write biggest execution time.
    double maxTime = 0.0;
    MPI_Reduce( &executionTime, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD );

    if( globalRank == 0 )
        printf("%0.6f\n", maxTime);

    MPI_Finalize();
} // done


int getPivot( MPI_Comm group, int rank, int groupSize, int* numbers, int backetSize )
{
    // Choose strategy.
    switch( pivotStrategy )
    {
        case PIVOT_LOCAL_MEDIAN : 
        {
            trace( "Selecting pivot by Local Median\n");
            int median = 0;

            // Rank 0 finds it's median.
            if( rank == 0 )
                median = getVectorMedian( numbers, backetSize );

            // Send it to the group.
            trace( "Broadcasting pivot %d\n", median );
            MPI_Bcast( &median, 1, MPI_INT, 0, group );
            trace( "Got from broadcast pivot %d\n", median );

            return( median );
        }
        break;

        case PIVOT_GROUP_MEDIAN : 
        {
            trace( "Selecting pivot by Group Median\n" );

            // Everybody find their median.
            int median = getVectorMedian( numbers, backetSize ); 

            // And exchange them.
            int allMedians[groupSize];
            trace( "Gathering pivot %d\n", median );
            MPI_Allgather( &median, 1, MPI_INT, allMedians, 1, MPI_INT, group );
            traceVector( allMedians, groupSize );

            // Get the median of all medians.
            median = getVectorMedian( allMedians, groupSize );
            return( median );
        }
        break;

        case PIVOT_GROUP_MEAN_MEDIAN :
        {
            trace( "Selecting pivot by Group Mean\n" );

            // Everybody find their median.
            int median = getVectorMedian( numbers, backetSize ); 

            // And exchange them.
            int allMedians[groupSize];
            trace( "Gathering pivot %d\n", median );
            MPI_Allgather( &median, 1, MPI_INT, allMedians, 1, MPI_INT, group );
            traceVector( allMedians, groupSize );

            // Get the mean value of all.
            median = getVectorMean( allMedians, groupSize );
            return( median );
        }
        break;
    }

    return( 0 );
} // getPivot


int* quicksort( MPI_Comm group, int rank, int groupSize, int* numbers, int* backetSize )
{
    // Recursion needs to stop sometime.
    if( groupSize <= 1 )
    {
        return( numbers );
    }    

    trace( "Entering quicksort groupSize %d\n", groupSize );
    traceVector( numbers, *backetSize );

    // Select pivot element in this process group.
    const int pivot = getPivot( group, rank, groupSize, numbers, *backetSize );
    trace( "Splitting with pivot %d\n", pivot );

    // Divide the data into two sets according to the pivot (low or high).
    const int gs = groupSize / 2;
    if( rank < gs )
    {
        // Low part group.
        
        // Find pair process.
        const int pair = rank + gs; 

        // Split numbers to low/high based on pivot.
        int* high = NULL; 
        int* low  = NULL;
        int lowSize  = 0;
        int highSize = 0;
        splitLowHigh( numbers, *backetSize, pivot, &low, &lowSize, &high, &highSize );
        traceVector( low, lowSize );
        traceVector( high, highSize );

        // This low part needs to send its high part. First send, then receive.
        sendBuffer( group, rank, pair, high, highSize );
        free( high );

        // Receive the other partie's low part.
        int otherLowSize = 0;
        int* otherLow = receiveBuffer( group, pair, &otherLowSize );
        traceVector( otherLow, otherLowSize );

        // Merge the received low part with the local low part.
        //free( numbers );
        numbers = merge( low, lowSize, otherLow, otherLowSize );
        *backetSize = lowSize + otherLowSize;
        traceVector( numbers, *backetSize );

        // Sort. 
        qsort( numbers, *backetSize, sizeof(int), intcompare );
        traceVector( numbers, *backetSize );

        // Split group in two. This is color 0.
        MPI_Comm_split( group, 0, 1, &group );
        MPI_Comm_size( group, &groupSize );
        MPI_Comm_rank( group, &rank );

        // Work with the new group.
        return( quicksort( group, rank, groupSize, numbers, backetSize ) );
    }
    else
    {
        // High part group.

        // Find pair process.
        const int pair = rank - gs; 

        // Split numbers to low/high based on pivot.
        int* high = NULL; 
        int* low  = NULL;
        int lowSize  = 0;
        int highSize = 0;
        splitLowHigh( numbers, *backetSize, pivot, &low, &lowSize, &high, &highSize );
        traceVector( low, lowSize );
        traceVector( high, highSize );

        // Receive the other partie's low part. Receive first.
        int otherHighSize = 0;
        int* otherHigh = receiveBuffer( group, pair, &otherHighSize );
        traceVector( otherHigh, otherHighSize );

        // This high part needs to send its low part.
        sendBuffer( group, rank, pair, low, lowSize );
        free( low );

        // Merge the received high part with the local high part.
        //free( numbers );
        numbers = merge( high, highSize, otherHigh, otherHighSize );
        *backetSize = highSize + otherHighSize;
        traceVector( numbers, *backetSize );

        // Sort. 
        qsort( numbers, *backetSize, sizeof(int), intcompare );
        traceVector( numbers, *backetSize );

        // Split group in two. This is color 1.
        MPI_Comm_split( group, 1, 1, &group );
        MPI_Comm_size( group, &groupSize );
        MPI_Comm_rank( group, &rank );

        // Work with the new group.
        return( quicksort( group, rank, groupSize, numbers, backetSize ) );
    }
} // quicksort


int main(int argc, char *argv[])
{
    startUp(argc, argv); 

    // 1. Divide the data into globalNump equal parts, one per process.
    int backetSize = 0;
    int* numbers = readFile( inputFile, globalRank, globalNump, &backetSize );

    // Let everyone finish loading. (Try removing the barrier)
    MPI_Barrier(MPI_COMM_WORLD);

    // Start the timer. Do not include file operations.
    executionTime = MPI_Wtime();

    // 2. Sort this backet locally. (This could be a first step in quicksort below, but looks nicer here)
    qsort( numbers, backetSize, sizeof(int), intcompare );

    // In the very special case of only one process, no global sorting needs to take place.
    if( globalNump > 1 )
    {
        // 3. Global sort. (Recursion starts here)
        numbers = quicksort( MPI_COMM_WORLD, globalRank, globalNump, numbers, &backetSize );

        // 4. Gather data from all processes. 
        if( globalRank != 0 )
            // All processes send to Zero. 
            sendBuffer( MPI_COMM_WORLD, globalRank, 0, numbers, backetSize );
        else
        {
            // Zero process gathers data.
            for( int r = 1; r < globalNump; ++r )
            {
                int bufferSize = 0;
                int* buffer = receiveBuffer( MPI_COMM_WORLD, r, &bufferSize );
                numbers = merge( numbers, backetSize, buffer, bufferSize );
                backetSize += bufferSize;
                traceVector( numbers, backetSize );
            }
        }
    }
    
    // Measure time. Exclude file write. 
    executionTime = MPI_Wtime() - executionTime;

    // Write file.
    if( globalRank == 0 )
        writeFile( outputFile, numbers, backetSize );

    // Done. (Two done(s), to dance, too much coffee)
    done();
} // main
